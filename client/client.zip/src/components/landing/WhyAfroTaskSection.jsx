import { useRef } from "react";
import { Link } from "react-router-dom";
import { motion, useInView } from "framer-motion";
import { IoIosArrowForward } from "react-icons/io";

export default function WhyAfroTaskSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="bg-gradient-to-br from-[#FB9E01] via-[#E68F07] to-[#C57810] w-full h-auto md:p-12 p-6 mx-2 lg:mx-8 py-6 lg:py-12 m-2 md:m-5 flex flex-col justify-center lg:flex-row items-center rounded-2xl md:rounded-3xl gap-4 overflow-visible relative shadow-2xl"
    >
      <div className="w-full gap-6 md:gap-12 flex flex-col z-10 md:text-left md:justify-start md:items-start lg:w-4/5">
        <h1 className="text-sm md:text-lg lg:text-xl font-semibold">
          Why Afro Task is Changing Freelancing in Africa
        </h1>
        <p className="text-xs md:text-sm lg:text-lg opacity-90">
          Freelancing is no longer just a side hustle — it's becoming the
          future of work in Africa. With young, talented professionals
          looking for opportunities beyond traditional office jobs, Afro
          Task is creating a space where skills meet demand in a truly
          African way.
        </p>
        <div className="self-start mt-4 md:flex">
          <Link to="/blogs">
            <button className="text-black bg-white flex flex-row lg:w-[160px] lg:justify-center items-center py-2 px-6 md:py-2 md:px-8 rounded-2xl md:rounded-3xl shadow-lg text-sm  font-semibold group transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-xl">
              Read More{" "}
              <IoIosArrowForward className="font-semibold text-sm transition-transform duration-300 group-hover:translate-x-2" />
            </button>
          </Link>
        </div>
      </div>

      <div className="flex flex-col md:flex-col lg:justify-between md:justify-start justify-center items-center gap-4 w-full lg:w-2/5 relative z-0 md:mt-0">
        <div className="w-full md:-mr-16">
          <img
            src="/img/whisk.png"
            alt="Whisk"
            className="lg:rounded-l-3xl w-full md:translate-x-14 hidden lg:block md:hidden"
          />
        </div>
      </div>
    </motion.div>
  );
}
